# -*- coding: utf-8 -*-
"""批量UV展开与材质关联 (Batch UV Unwrap & Material Region Linker)

安装:
    Blender > 编辑 > 偏好设置 > 附加组件 > 从磁盘安装 > 选择本文件 > 启用。

用法:
    1. 物体模式下选中若干网格物体, 点 "批量展开选中物体"。
    2. 把已经分好材质的物体设为活动物体(最后点选的那个), 其余要保持一致的
       物体一起选中, 点 "关联材质到选中物体"。

原理:
    * 批量展开: 逐个(或一次性)进入编辑模式全选面, 调用 Blender 自带的
      智能UV投影 / 展开 / 光照图打包 / 立方体投影。
    * 关联材质: 以活动物体为源, 按 UV 展开图中的位置为每个目标面找到源物体
      上对应的面, 取来该面的材质槽(材质数据块共享), 于是分区域的材质分布
      被完整复制过去。找不到对应面时可按设置保留原材质 / 取最近面 / 填充。
"""

bl_info = {
    "name": "批量UV展开与材质关联 (Batch UV & Material Linker)",
    "author": "Codex",
    "version": (1, 1, 0),
    "blender": (2, 90, 0),
    "location": "3D视图 > 侧边栏(N) > UV工具 / 物体菜单",
    "description": "物体模式下批量对选中物体执行自动UV展开(自动跳过摄像机/灯光), 检测镜像修改器与已应用的镜像, "
                   "并按UV展开图把源物体的分区域材质分布关联到其它物体(镜像物体自动对齐UV)",
    "warning": "",
    "doc_url": "",
    "category": "UV",
}

import contextlib
import itertools
import math

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, Panel, PropertyGroup


MATCH_UV = 'UV'
MATCH_FACE = 'FACE'
MATCH_POSITION = 'POSITION'
MIRROR_AXES = ("X", "Y", "Z")
MIRROR_AXIS_INDEX = {"X": 0, "Y": 1, "Z": 2}


# ---------------------------------------------------------------------------
# 通用小工具
# ---------------------------------------------------------------------------

def get_settings(context):
    """面板/算子共用的设置(存在 Scene 上, 随 .blend 一起保存)。"""
    return context.scene.uvmb_settings


def mesh_objects(context, skip=None):
    """当前选中的网格物体(可排除某个物体)。"""
    result = []
    for obj in context.selected_objects:
        if obj.type != 'MESH' or obj.data is None:
            continue
        if skip is not None and obj is skip:
            continue
        result.append(obj)
    return result


def non_mesh_objects(context, skip=None):
    """选中的非网格物体(摄像机、灯光、空物体等), 展开/关联时一律跳过。"""
    result = []
    for obj in context.selected_objects:
        if obj.type == 'MESH' and obj.data is not None:
            continue
        if skip is not None and obj is skip:
            continue
        result.append(obj)
    return result


def object_kind_label(obj):
    """把物体类型翻译成中文, 用于结果列表里的说明。"""
    labels = {
        'CAMERA': "摄像机",
        'LIGHT': "灯光",
        'EMPTY': "空物体",
        'CURVE': "曲线",
        'SURFACE': "曲面",
        'FONT': "文字",
        'META': "元球",
        'ARMATURE': "骨架",
        'LATTICE': "晶格",
        'SPEAKER': "扬声器",
        'GPENCIL': "蜡笔",
    }
    return labels.get(obj.type, obj.type)


def mirror_status_suffix(obj, settings):
    """展开完成后, 在结果里附上这个物体的镜像情况。"""
    if not getattr(settings, "handle_mirror", True):
        return ""
    try:
        info = object_mirror_info(obj, settings)
    except Exception:
        return ""
    if not info["has_mirror"]:
        return ""
    return " · " + info["text"]


def skipped_report_rows(context, skip=None):
    """被跳过的非网格物体, 也写进结果列表。"""
    rows = []
    for obj in non_mesh_objects(context, skip=skip):
        rows.append((obj.name, 0, 0, "已跳过 · %s不是网格物体" % object_kind_label(obj)))
    return rows


def skipped_summary(context, skip=None):
    """一句话说明跳过了哪些非网格物体。"""
    counts = {}
    for obj in non_mesh_objects(context, skip=skip):
        label = object_kind_label(obj)
        counts[label] = counts.get(label, 0) + 1
    if not counts:
        return ""
    parts = ["%s x%d" % (label, count) for label, count in sorted(counts.items())]
    return "已自动跳过 %d 个非网格物体 (%s)" % (sum(counts.values()), ", ".join(parts))


def active_uv_layer(mesh):
    """返回网格当前活动的 UV 层; 没有则返回 None。"""
    if mesh is None or not mesh.uv_layers:
        return None
    layer = mesh.uv_layers.active
    if layer is None:
        layer = mesh.uv_layers[0]
    return layer


def uv_face_stats(poly, uv_layer):
    """面在 UV 空间中的 (中心U, 中心V, 面积); 面无效时返回 None。"""
    indices = poly.loop_indices
    count = len(indices)
    if count < 3:
        return None
    data = uv_layer.data
    us = []
    vs = []
    sum_u = 0.0
    sum_v = 0.0
    for loop_index in indices:
        uv = data[loop_index].uv
        u = float(uv[0])
        v = float(uv[1])
        us.append(u)
        vs.append(v)
        sum_u += u
        sum_v += v
    inv = 1.0 / count
    center_u = sum_u * inv
    center_v = sum_v * inv
    area2 = 0.0
    for i in range(count):
        j = i + 1
        if j == count:
            j = 0
        area2 += us[i] * vs[j] - us[j] * vs[i]
    return center_u, center_v, abs(area2) * 0.5


def world_face_center(obj, poly):
    """面中心的世界坐标(3D 匹配模式使用)。"""
    center = obj.matrix_world @ poly.center
    return float(center[0]), float(center[1]), float(center[2])


def face_area_3d(poly):
    try:
        return float(poly.area)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 面索引: 把源物体的面按坐标塞进网格哈希, 支持容差查询
# ---------------------------------------------------------------------------

class SpatialFaceIndex:
    """面中心落进边长为 tolerance 的格子, 查询时检查相邻 3^dim 个格子,
    保证落在容差内的面都能被找到。payload 里存源面的 material_index。
    """

    def __init__(self, tolerance, dim):
        self.tolerance = max(float(tolerance), 1e-9)
        self.dim = int(dim)
        self.cells = {}
        self.coords = {}
        self.extra = {}
        self.payload = {}
        self._offsets = list(itertools.product((-1, 0, 1), repeat=self.dim))

    def _cell_key(self, coord):
        return tuple(int(math.floor(c / self.tolerance)) for c in coord)

    @staticmethod
    def _distance(a, b):
        total = 0.0
        for i in range(len(a)):
            delta = a[i] - b[i]
            total += delta * delta
        return math.sqrt(total)

    @staticmethod
    def _extra_score(extra_a, extra_b):
        """面积差异作为次要判据, 避免 UV 重叠处选错面。"""
        if extra_a is None or extra_b is None:
            return 0.0
        if extra_a <= 1e-12 or extra_b <= 1e-12:
            return 0.0
        return 0.05 * abs(math.log(extra_a / extra_b))

    def add(self, key, coord, extra=None, payload=None):
        self.coords[key] = tuple(float(c) for c in coord)
        self.extra[key] = extra
        self.payload[key] = payload
        self.cells.setdefault(self._cell_key(coord), []).append(key)

    def find(self, coord, extra=None):
        """容差内匹配, 返回 (key, 得分); 找不到返回 (None, None)。"""
        base = self._cell_key(coord)
        best_key = None
        best_score = None
        for offset in self._offsets:
            cell = tuple(base[i] + offset[i] for i in range(self.dim))
            for key in self.cells.get(cell, ()):
                distance = self._distance(coord, self.coords[key])
                if distance > self.tolerance:
                    continue
                score = distance / self.tolerance
                score += self._extra_score(self.extra.get(key), extra)
                if best_score is None or score < best_score:
                    best_score = score
                    best_key = key
        return best_key, best_score

    def find_nearest(self, coord):
        """不限容差地找最近的面(逐圈扩大邻域, 兜底全量扫描)。"""
        base = self._cell_key(coord)
        best_key = None
        best_distance = None
        for ring in range(1, 6):
            for offset in itertools.product(range(-ring, ring + 1), repeat=self.dim):
                if max(abs(o) for o in offset) != ring:
                    continue
                cell = tuple(base[i] + offset[i] for i in range(self.dim))
                for key in self.cells.get(cell, ()):
                    distance = self._distance(coord, self.coords[key])
                    if best_distance is None or distance < best_distance:
                        best_distance = distance
                        best_key = key
            if best_key is not None:
                return best_key
        if len(self.coords) <= 20000:
            for key, value in self.coords.items():
                distance = self._distance(coord, value)
                if best_distance is None or distance < best_distance:
                    best_distance = distance
                    best_key = key
        return best_key


def build_source_index(source, mode, uv_tolerance, position_tolerance, uv_layer):
    """为源物体建面索引。"""
    mesh = source.data
    if mode == MATCH_UV:
        index = SpatialFaceIndex(uv_tolerance, 2)
        if uv_layer is None:
            return index
        for poly in mesh.polygons:
            stats = uv_face_stats(poly, uv_layer)
            if stats is None:
                continue
            index.add(poly.index, (stats[0], stats[1]), stats[2], poly.material_index)
        return index

    index = SpatialFaceIndex(position_tolerance, 3)
    for poly in mesh.polygons:
        index.add(poly.index, world_face_center(source, poly), face_area_3d(poly), poly.material_index)
    return index


def compute_face_map(source, target, target_mesh, mode, settings, index, target_uv, use_nearest=None):
    """返回 (目标面序号 -> 源面序号 的列表, 匹配上的面数)。-1 表示未匹配。"""
    count = len(target_mesh.polygons)
    mapping = [-1] * count

    if mode == MATCH_FACE:
        limit = min(len(source.data.polygons), count)
        for i in range(limit):
            mapping[i] = i
        return mapping, limit

    if use_nearest is None:
        use_nearest = settings.unmatched == 'NEAREST'
    matched = 0
    for poly in target_mesh.polygons:
        if mode == MATCH_UV:
            stats = uv_face_stats(poly, target_uv)
            if stats is None:
                continue
            coord = (stats[0], stats[1])
            extra = stats[2]
        else:
            coord = world_face_center(target, poly)
            extra = face_area_3d(poly)

        key, _score = index.find(coord, extra)
        if key is None and use_nearest:
            key = index.find_nearest(coord)
        if key is not None:
            mapping[poly.index] = key
            matched += 1
    return mapping, matched


# ---------------------------------------------------------------------------
# 材质槽处理
# ---------------------------------------------------------------------------

def mesh_diagonal(mesh):
    """网格局部包围盒的对角线长度, 用来把容差换算成相对值。"""
    vertices = mesh.vertices
    count = len(vertices)
    if count == 0:
        return 1.0
    step = max(1, count // 4000)
    lows = [float("inf")] * 3
    highs = [float("-inf")] * 3
    for index in range(0, count, step):
        co = vertices[index].co
        for axis in range(3):
            value = float(co[axis])
            if value < lows[axis]:
                lows[axis] = value
            if value > highs[axis]:
                highs[axis] = value
    total = 0.0
    for axis in range(3):
        total += (highs[axis] - lows[axis]) ** 2
    return max(math.sqrt(total), 1e-6)


def mirror_tolerance_for(mesh, settings):
    """镜像检测容差: 设置里的比例 x 物体包围盒对角线。"""
    return max(float(settings.mirror_tolerance) * mesh_diagonal(mesh), 1e-9)


def mirror_modifier_info(obj):
    """读取物体上 Mirror 修改器的信息(修改器还没应用时用这个)。"""
    for modifier in getattr(obj, "modifiers", ()):
        if modifier.type != 'MIRROR':
            continue
        flags = list(getattr(modifier, "use_axis", (False, True, False)))
        axes = [name for index, name in enumerate(MIRROR_AXES)
                if index < len(flags) and flags[index]]
        return {
            "source": "modifier",
            "axes": axes,
            "axis": axes[0] if axes else 'X',
            "mirror_u": bool(getattr(modifier, "use_mirror_u", False)),
            "mirror_v": bool(getattr(modifier, "use_mirror_v", False)),
            "mirror_object": getattr(modifier, "mirror_object", None),
            "clipping": bool(getattr(modifier, "use_clip", False)),
            "bisect": [bool(value) for value in getattr(modifier, "use_bisect_axis", (False,) * 3)],
        }
    return None


def vertex_symmetry_axis(mesh, tolerance, limit=4000):
    """几何检测: 网格是否关于某条局部轴平面对称。

    镜像修改器即使已经应用(网格里已经有对称的两半), 也能通过这个方法查出来。
    返回 {"axis": "X", "ratio": 0.99, "plane": 0.0} 或 None。
    """
    vertices = mesh.vertices
    count = len(vertices)
    if count < 8:
        return None
    step = max(1, count // limit)
    coords = [tuple(float(c) for c in vertices[index].co) for index in range(0, count, step)]
    if len(coords) < 8:
        return None

    index = SpatialFaceIndex(tolerance, 3)
    for key, coord in enumerate(coords):
        index.add(key, coord)

    best = None
    for axis_index, axis_name in enumerate(MIRROR_AXES):
        values = [coord[axis_index] for coord in coords]
        plane = (min(values) + max(values)) * 0.5
        hits = 0
        off_plane = 0
        for coord in coords:
            mirrored = list(coord)
            mirrored[axis_index] = 2.0 * plane - coord[axis_index]
            if abs(mirrored[axis_index] - coord[axis_index]) > tolerance:
                off_plane += 1
            key, _score = index.find(tuple(mirrored))
            if key is not None:
                hits += 1
        if off_plane == 0:
            continue
        ratio = hits / float(len(coords))
        if best is None or ratio > best["ratio"]:
            best = {
                "source": "geometry",
                "axis": axis_name,
                "index": axis_index,
                "ratio": ratio,
                "plane": plane,
            }
    if best is not None and best["ratio"] >= 0.95:
        return best
    return None


def object_mirror_info(obj, settings):
    """汇总一个物体的镜像情况, 返回带中文说明的字典。"""
    info = {
        "object": obj.name,
        "modifier": None,
        "geometry": None,
        "has_mirror": False,
        "text": "未检测到镜像",
    }
    if obj.type != 'MESH' or obj.data is None:
        return info
    info["modifier"] = mirror_modifier_info(obj)
    try:
        info["geometry"] = vertex_symmetry_axis(obj.data, mirror_tolerance_for(obj.data, settings))
    except Exception:
        info["geometry"] = None
    parts = []
    modifier = info["modifier"]
    if modifier is not None:
        uv_axes = []
        if modifier["mirror_u"]:
            uv_axes.append("U")
        if modifier["mirror_v"]:
            uv_axes.append("V")
        text = "镜像修改器: %s轴" % ("+".join(modifier["axes"]) or "?")
        if uv_axes:
            text += ", 修改器已开启UV镜像(%s)" % "/".join(uv_axes)
        parts.append(text)
    geometry = info["geometry"]
    if geometry is not None:
        parts.append(
            "网格关于%s轴对称(相似度 %.0f%%, 常见于已应用的镜像修改器)"
            % (geometry["axis"], geometry["ratio"] * 100.0)
        )
    if parts:
        info["has_mirror"] = True
        info["text"] = "; ".join(parts)
    return info


def world_face_centers(obj, limit=6000):
    """物体所有面中心的世界坐标(必要时抽样)。"""
    polygons = obj.data.polygons
    count = len(polygons)
    if count == 0:
        return []
    step = max(1, count // limit)
    return [world_face_center(obj, polygons[index]) for index in range(0, count, step)]


def mirror_point(coord, delta, axis_index, plane):
    """镜像变换: 先平移 delta, 再沿 axis 轴关于 plane 镜像。"""
    out = [coord[axis] + delta[axis] for axis in range(3)]
    out[axis_index] = 2.0 * plane - out[axis_index]
    return tuple(out)


def unmirror_point(coord, delta, axis_index, plane):
    """mirror_point 的反变换(镜像本身是对合变换, 只要把平移反过来)。"""
    mirrored = list(coord)
    mirrored[axis_index] = 2.0 * plane - mirrored[axis_index]
    return tuple(mirrored[axis] - delta[axis] for axis in range(3))


def mirror_relation(source, target, settings):
    """判断 target 是不是 source 的镜像副本(按世界坐标的面中心比对)。

    比对前先把两个物体各自挪到共同中心, 所以"形状相同、只是位置不同"的普通副本
    不会被误判成镜像; 镜像变换由"平移 + 沿某轴镜像"两部分组成, 因此兼容:
      * 左右两半分成两个物体的情况(镜像面在接缝上);
      * 整个物体镜像后又搬到别处的情况(镜像面把位移一起吃掉了)。
    返回 {"axis": "X", "index": 0, "ratio": r, "plane": p, "delta": [...]} 或 None。
    """
    if not settings.handle_mirror:
        return None
    source_centers = world_face_centers(source)
    target_centers = world_face_centers(target)
    if not source_centers or not target_centers:
        return None
    tolerance = max(mirror_tolerance_for(source.data, settings), mirror_tolerance_for(target.data, settings))

    target_index = SpatialFaceIndex(tolerance, 3)
    for key, coord in enumerate(target_centers):
        target_index.add(key, coord)

    source_centroid = [sum(coord[axis] for coord in source_centers) / len(source_centers) for axis in range(3)]
    target_centroid = [sum(coord[axis] for coord in target_centers) / len(target_centers) for axis in range(3)]

    delta = [target_centroid[axis] - source_centroid[axis] for axis in range(3)]

    # 纯平移(普通副本)的情况: 把源按两个中心的差挪过去再比
    direct_hits = 0
    for coord in source_centers:
        moved = tuple(coord[axis] + delta[axis] for axis in range(3))
        key, _score = target_index.find(moved)
        if key is not None:
            direct_hits += 1
    direct_ratio = direct_hits / float(len(source_centers))

    best = None
    for axis_index, axis_name in enumerate(MIRROR_AXES):
        if settings.mirror_axis not in ("AUTO", axis_name):
            continue
        source_values = [coord[axis_index] for coord in source_centers]
        target_values = [coord[axis_index] for coord in target_centers]
        # 平移之后两个物体的中心重合, 两个候选镜像面: 目标中心, 以及由包围盒推出来的
        shifted_max = max(source_values) + delta[axis_index]
        shifted_min = min(source_values) + delta[axis_index]
        planes = [
            target_centroid[axis_index],
            ((min(target_values) + shifted_max) + (max(target_values) + shifted_min)) * 0.25,
        ]
        for plane in planes:
            hits = 0
            for coord in source_centers:
                mirrored = mirror_point(coord, delta, axis_index, plane)
                key, _score = target_index.find(mirrored)
                if key is not None:
                    hits += 1
            ratio = hits / float(len(source_centers))
            if best is None or ratio > best["ratio"]:
                best = {
                    "axis": axis_name,
                    "index": axis_index,
                    "ratio": ratio,
                    "plane": plane,
                    "delta": list(delta),
                    "direct_ratio": direct_ratio,
                }
    if best is None or best["ratio"] < 0.9:
        return None
    # 直接平移就能对上, 说明两者不是镜像关系(比如同一形状的普通副本)
    if direct_ratio >= best["ratio"] - 0.05:
        return None
    return best


def face_mirror_pairs(source, target, relation, tolerance):
    """目标每个面 -> 源里与之镜像对应的面序号(-1 表示没找到)。"""
    axis_index = relation["index"]
    plane = relation["plane"]
    delta = relation.get("delta", (0.0, 0.0, 0.0))
    index = SpatialFaceIndex(tolerance, 3)
    for poly in source.data.polygons:
        index.add(poly.index, world_face_center(source, poly))
    pairs = [-1] * len(target.data.polygons)
    for poly in target.data.polygons:
        coord = unmirror_point(world_face_center(target, poly), delta, axis_index, plane)
        key, _score = index.find(coord)
        if key is not None:
            pairs[poly.index] = key
    return pairs


UV_VARIANT_LABELS = {
    'NONE': "不改动",
    'COPY': "按镜像对应关系把源的UV逐面复制过来",
    'COPY_REVERSED': "按镜像对应关系(反向循环)把源的UV复制过来",
    'MIRROR_U': "把UV沿水平方向镜像(U -> 1-U)",
    'MIRROR_V': "把UV沿垂直方向镜像(V -> 1-V)",
    'MIRROR_UV': "把UV同时沿水平+垂直镜像",
}


def uv_variant_values(variant, source_mesh, source_uv, target_mesh, target_uv, pairs):
    """算出某个变体下目标 UV 的完整数组; 无法计算时返回 None。"""
    count = len(target_mesh.loops)
    values = [0.0] * (count * 2)
    target_uv.data.foreach_get("uv", values)
    if variant == 'NONE':
        return None
    if variant in ('MIRROR_U', 'MIRROR_V', 'MIRROR_UV'):
        flip_u = variant in ('MIRROR_U', 'MIRROR_UV')
        flip_v = variant in ('MIRROR_V', 'MIRROR_UV')
        for index in range(count):
            if flip_u:
                values[index * 2] = 1.0 - values[index * 2]
            if flip_v:
                values[index * 2 + 1] = 1.0 - values[index * 2 + 1]
        return values
    if variant not in ('COPY', 'COPY_REVERSED') or pairs is None or source_uv is None:
        return None

    source_values = [0.0] * (len(source_mesh.loops) * 2)
    source_uv.data.foreach_get("uv", source_values)
    source_polygons = source_mesh.polygons
    target_polygons = target_mesh.polygons
    source_loops_data = source_mesh.loops
    target_loops_data = target_mesh.loops
    for target_face, source_face in enumerate(pairs):
        if source_face < 0 or source_face >= len(source_polygons):
            continue
        target_loops = target_polygons[target_face].loop_indices
        source_loops = source_polygons[source_face].loop_indices
        total = len(target_loops)
        if total != len(source_loops):
            continue
        if variant == 'COPY_REVERSED':
            mapping = [source_loops[total - 1 - offset] for offset in range(total)]
        else:
            # 镜像出来的物体通常顶点序号是一致的, 优先按顶点序号对应;
            # 对不上时退回按循环顺序对应
            by_vertex = {}
            for source_loop in source_loops:
                by_vertex[source_loops_data[source_loop].vertex_index] = source_loop
            mapping = []
            for target_loop in target_loops:
                source_loop = by_vertex.get(target_loops_data[target_loop].vertex_index)
                if source_loop is None:
                    mapping = []
                    break
                mapping.append(source_loop)
            if not mapping:
                mapping = list(source_loops)
        for offset, target_loop in enumerate(target_loops):
            source_loop = mapping[offset]
            values[target_loop * 2] = source_values[source_loop * 2]
            values[target_loop * 2 + 1] = source_values[source_loop * 2 + 1]
    return values


def write_uv_values(target_mesh, target_uv, values):
    target_uv.data.foreach_set("uv", values)
    target_mesh.update()


MIRROR_UV_MODES = {
    'AUTO': ('NONE', 'COPY', 'COPY_REVERSED', 'MIRROR_U', 'MIRROR_V', 'MIRROR_UV'),
    'U': ('NONE', 'COPY', 'COPY_REVERSED', 'MIRROR_U'),
    'V': ('NONE', 'COPY', 'COPY_REVERSED', 'MIRROR_V'),
    'UV': ('NONE', 'COPY', 'COPY_REVERSED', 'MIRROR_UV'),
}


def align_mirrored_uv(source, target, target_mesh, settings, source_uv, target_uv, index):
    """镜像物体的 UV 对齐: 找出匹配率最高的方案并应用。

    只有当 target 确实是 source 的镜像副本时才动手; 返回一句给用户看的说明。
    """
    if not settings.handle_mirror or not settings.mirror_uv_fix:
        return ""
    if source_uv is None or target_uv is None:
        return ""
    relation = mirror_relation(source, target, settings)
    if relation is None:
        return ""

    tolerance = max(mirror_tolerance_for(source.data, settings), mirror_tolerance_for(target_mesh, settings))
    pairs = face_mirror_pairs(source, target, relation, tolerance)
    original = [0.0] * (len(target_mesh.loops) * 2)
    target_uv.data.foreach_get("uv", original)

    baseline = None
    best_variant = 'NONE'
    best_values = None
    best_count = -1
    for variant in MIRROR_UV_MODES.get(settings.mirror_uv_axis, MIRROR_UV_MODES['AUTO']):
        values = uv_variant_values(variant, source.data, source_uv, target_mesh, target_uv, pairs)
        if values is not None:
            write_uv_values(target_mesh, target_uv, values)
        _mapping, matched = compute_face_map(
            source, target, target_mesh, MATCH_UV, settings, index, target_uv, use_nearest=False
        )
        if values is not None:
            write_uv_values(target_mesh, target_uv, original)
        if variant == 'NONE':
            baseline = matched
        if matched > best_count:
            best_count = matched
            best_variant = variant
            best_values = values

    axis = relation["axis"]
    if best_variant == 'NONE' or best_values is None:
        return "检测到与源成镜像关系(%s轴), 原UV已是最佳匹配, 未改动" % axis
    write_uv_values(target_mesh, target_uv, best_values)
    return "检测到与源成镜像关系(%s轴), 已自动对齐UV: %s (匹配 %d -> %d 个面)" % (
        axis, UV_VARIANT_LABELS.get(best_variant, best_variant), baseline or 0, best_count
    )

def ensure_single_user_mesh(target, settings):
    """目标网格被多个物体共用时先复制一份, 避免改到别的物体。"""
    mesh = target.data
    if not settings.make_single_user:
        return mesh
    users = getattr(mesh, "users", None)
    if users is not None and users > 1:
        mesh = mesh.copy()
        target.data = mesh
    return mesh


def copy_uv_layout(source_mesh, target_mesh):
    """把源物体的 UV 布局整体复制到目标物体(要求循环数一致)。"""
    source_uv = active_uv_layer(source_mesh)
    if source_uv is None:
        return False
    if len(source_mesh.loops) != len(target_mesh.loops):
        return False
    target_uv = active_uv_layer(target_mesh)
    if target_uv is None:
        target_uv = target_mesh.uv_layers.new(name=source_uv.name)
    values = [0.0] * (len(source_mesh.loops) * 2)
    source_uv.data.foreach_get("uv", values)
    target_uv.data.foreach_set("uv", values)
    target_mesh.update()
    return True


def build_slot_map(source_mesh, target_mesh):
    """把源物体的材质槽并入目标物体, 返回 {源槽序号: 目标槽序号}。

    已存在的材质直接复用, 缺失的才追加; 追加的是同一个材质数据块,
    所以两个物体共享材质, 改一个材质两边都会变。
    """
    slot_map = {}
    target_materials = target_mesh.materials
    for source_index, material in enumerate(source_mesh.materials):
        if material is None:
            continue
        found = None
        for target_index in range(len(target_materials)):
            if target_materials[target_index] == material:
                found = target_index
                break
        if found is None:
            target_materials.append(material)
            found = len(target_materials) - 1
        slot_map[source_index] = found
    return slot_map


def apply_material_donor(target_mesh, face_map, source_mesh, slot_map, unmatched, fallback_source_face):
    """按面映射写入 material_index, 返回实际写入的面数。"""
    polygons = target_mesh.polygons
    new_indices = [0] * len(polygons)
    polygons.foreach_get("material_index", new_indices)
    source_polygons = source_mesh.polygons
    applied = 0

    for face_index, source_face in enumerate(face_map):
        if source_face < 0:
            if unmatched == 'FIRST' and fallback_source_face >= 0:
                source_face = fallback_source_face
            else:
                continue
        if source_face >= len(source_polygons):
            continue
        target_slot = slot_map.get(source_polygons[source_face].material_index)
        if target_slot is None:
            continue
        new_indices[face_index] = target_slot
        applied += 1

    polygons.foreach_set("material_index", new_indices)
    target_mesh.update()
    return applied


def link_materials(context, source, targets, settings):
    """把源物体的分区域材质分布关联到各目标物体。

    返回 (rows, error, stats)。
    rows = [(物体名, 写入面数, 总面数, 说明)];
    stats = {"matched": 真正找到对应面的数量, "faces": 目标总面数, "objects": 目标物体数}。
    """
    rows = []
    stats = {"matched": 0, "faces": 0, "objects": 0}
    source_mesh = source.data
    source_polygons = source_mesh.polygons
    mode = settings.match_mode

    source_uv = active_uv_layer(source_mesh)
    if mode == MATCH_UV and source_uv is None:
        return [], "源物体 [%s] 没有 UV 图层, 请先执行 UV 展开。" % source.name, stats

    if mode == MATCH_UV and settings.copy_uv:
        for target in targets:
            target_mesh = ensure_single_user_mesh(target, settings)
            copy_uv_layout(source_mesh, target_mesh)

    index = build_source_index(
        source, mode, settings.uv_tolerance, settings.position_tolerance, source_uv
    )
    fallback_source_face = 0 if len(source_polygons) else -1

    for target in targets:
        name = target.name
        try:
            stats["objects"] += 1
            target_mesh = ensure_single_user_mesh(target, settings)
            target_uv = active_uv_layer(target_mesh)
            if mode == MATCH_UV and target_uv is None:
                stats["faces"] += len(target_mesh.polygons)
                rows.append((name, 0, len(target_mesh.polygons), "目标物体没有 UV 图层"))
                continue

            mirror_note = ""
            if mode == MATCH_UV:
                try:
                    mirror_note = align_mirrored_uv(
                        source, target, target_mesh, settings, source_uv, target_uv, index
                    )
                except Exception as exc:
                    mirror_note = "镜像UV处理失败: %s" % exc

            face_map, matched = compute_face_map(
                source, target, target_mesh, mode, settings, index, target_uv
            )
            stats["matched"] += matched
            stats["faces"] += len(target_mesh.polygons)
            slot_map = build_slot_map(source_mesh, target_mesh)
            applied = apply_material_donor(
                target_mesh, face_map, source_mesh, slot_map, settings.unmatched, fallback_source_face
            )
            total = len(target_mesh.polygons)
            note = "" if matched >= total else "未匹配 %d 个面" % (total - matched)
            if mirror_note:
                note = (note + " | " + mirror_note) if note else mirror_note
            rows.append((name, applied, total, note))
        except Exception as exc:
            rows.append((name, 0, 0, "失败: %s" % exc))
    return rows, None, stats


# ---------------------------------------------------------------------------
# UV 展开
# ---------------------------------------------------------------------------

def operator_property_ids(op):
    """取算子支持的属性名集合; 取不到时返回 None(表示不过滤)。"""
    try:
        rna = op.get_rna_type()
    except Exception:
        return None
    try:
        return set(prop.identifier for prop in rna.properties)
    except Exception:
        return None


def operator_enum_ids(op, prop_name):
    try:
        rna = op.get_rna_type()
        for prop in rna.properties:
            if prop.identifier == prop_name:
                return [item.identifier for item in prop.enum_items]
    except Exception:
        pass
    return []


def filter_kwargs(op, kwargs):
    """只传当前 Blender 版本真正存在的参数, 兼容各版本算子签名差异。"""
    allowed = operator_property_ids(op)
    if allowed is None:
        return dict(kwargs)
    return {key: value for key, value in kwargs.items() if key in allowed}


# 智能投影的「旋转方式」在 5.x 变成了 AXIS_ALIGNED_X / Y, 并且去掉了 CARDINAL,
# 这里给出替代顺序, 保证任何版本下送进算子的都是合法枚举值。
ROTATE_METHOD_FALLBACKS = {
    'AXIS_ALIGNED': ('AXIS_ALIGNED_Y', 'AXIS_ALIGNED_X', 'CARDINAL'),
    'AXIS_ALIGNED_Y': ('AXIS_ALIGNED', 'AXIS_ALIGNED_X', 'CARDINAL'),
    'AXIS_ALIGNED_X': ('AXIS_ALIGNED', 'AXIS_ALIGNED_Y', 'CARDINAL'),
    'CARDINAL': ('AXIS_ALIGNED', 'AXIS_ALIGNED_Y', 'AXIS_ALIGNED_X'),
}


def pick_enum_value(requested, allowed, fallbacks=None):
    """把用户选的值映射成当前版本真正支持的枚举值。"""
    if not allowed:
        return requested
    if requested in allowed:
        return requested
    for candidate in (fallbacks or {}).get(requested, ()):
        if candidate in allowed:
            return candidate
    return allowed[0]


@contextlib.contextmanager
def view3d_context(context):
    """尽量在 3D 视图区域里执行 UV 算子; 后台运行/无窗口时原样执行。"""
    window = None
    area = None
    region = None
    window_manager = getattr(context, "window_manager", None)
    if window_manager is not None:
        for win in window_manager.windows:
            screen = getattr(win, "screen", None)
            for candidate in getattr(screen, "areas", []):
                if candidate.type == 'VIEW_3D':
                    window = win
                    area = candidate
                    for candidate_region in candidate.regions:
                        if candidate_region.type == 'WINDOW':
                            region = candidate_region
                            break
                    break
            if area is not None:
                break

    if area is None or not hasattr(context, "temp_override"):
        yield
        return

    overrides = {"window": window, "screen": window.screen, "area": area}
    if region is not None:
        overrides["region"] = region
    with context.temp_override(**overrides):
        yield


def run_unwrap_uv_ops(settings):
    """在编辑模式下对当前物体的所有面执行 UV 展开。"""
    method = settings.method

    if method == 'SMART':
        op = bpy.ops.uv.smart_project
        rotate = pick_enum_value(
            settings.rotate_method, operator_enum_ids(op, "rotate_method"), ROTATE_METHOD_FALLBACKS
        )
        margin_method = pick_enum_value(
            settings.margin_method, operator_enum_ids(op, "margin_method")
        )
        kwargs = {
            "angle_limit": settings.angle_limit,
            "island_margin": settings.island_margin,
            "area_weight": settings.area_weight,
            "correct_aspect": settings.correct_aspect,
            "scale_to_bounds": settings.scale_to_bounds,
            "margin_method": margin_method,
            "rotate_method": rotate,
        }
        bpy.ops.uv.smart_project(**filter_kwargs(op, kwargs))
        return

    if method == 'UNWRAP':
        methods = operator_enum_ids(bpy.ops.uv.unwrap, "method")
        unwrap_method = pick_enum_value(settings.unwrap_method, methods)
        kwargs = {
            "method": unwrap_method,
            "fill_holes": True,
            "correct_aspect": settings.correct_aspect,
            "margin": settings.margin,
            "margin_method": settings.margin_method,
        }
        bpy.ops.uv.unwrap(**filter_kwargs(bpy.ops.uv.unwrap, kwargs))
        if settings.pack_after:
            bpy.ops.uv.average_islands_scale()
            pack_kwargs = {
                "margin": settings.margin,
                "rotate": True,
                "margin_method": settings.margin_method,
            }
            bpy.ops.uv.pack_islands(**filter_kwargs(bpy.ops.uv.pack_islands, pack_kwargs))
        return

    if method == 'LIGHTMAP':
        # 4.x 用 margin, 5.x 改成 PREF_MARGIN_DIV, 两个都传, 由版本过滤取舍
        kwargs = {
            "margin": settings.margin,
            "PREF_MARGIN_DIV": settings.lightmap_margin,
        }
        bpy.ops.uv.lightmap_pack(**filter_kwargs(bpy.ops.uv.lightmap_pack, kwargs))
        return

    kwargs = {
        "cube_size": settings.cube_size,
        "correct_aspect": settings.correct_aspect,
        "clip_to_bounds": False,
        "scale_to_bounds": settings.scale_to_bounds,
    }
    bpy.ops.uv.cube_project(**filter_kwargs(bpy.ops.uv.cube_project, kwargs))


def unwrap_one_object(context, obj, settings):
    """切选择 -> 进编辑模式 -> 全选 -> UV 展开 -> 回物体模式。"""
    with view3d_context(context):
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        run_unwrap_uv_ops(settings)
        bpy.ops.object.mode_set(mode='OBJECT')
    obj.data.update()


def restore_selection(context, previous_selection, previous_active):
    """把用户原本的选择状态恢复回去。"""
    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        pass
    for obj in previous_selection:
        try:
            obj.select_set(True)
        except Exception:
            pass
    try:
        if previous_active is not None:
            context.view_layer.objects.active = previous_active
    except Exception:
        pass


def unwrap_all_objects(context, objects, settings):
    """返回 [(物体名, 状态文本)]。"""
    rows = []
    if not objects:
        return rows

    previous_selection = list(context.selected_objects)
    previous_active = context.view_layer.objects.active

    try:
        if settings.per_object:
            for obj in objects:
                try:
                    unwrap_one_object(context, obj, settings)
                    rows.append((obj.name, "已展开" + mirror_status_suffix(obj, settings)))
                except Exception as exc:
                    try:
                        bpy.ops.object.mode_set(mode='OBJECT')
                    except Exception:
                        pass
                    rows.append((obj.name, "失败: %s" % exc))
        else:
            try:
                with view3d_context(context):
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.select_all(action='DESELECT')
                    for obj in objects:
                        obj.select_set(True)
                    context.view_layer.objects.active = objects[0]
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.select_all(action='SELECT')
                    run_unwrap_uv_ops(settings)
                    bpy.ops.object.mode_set(mode='OBJECT')
                for obj in objects:
                    obj.data.update()
                    rows.append((obj.name, "已展开" + mirror_status_suffix(obj, settings)))
            except Exception as exc:
                try:
                    bpy.ops.object.mode_set(mode='OBJECT')
                except Exception:
                    pass
                for obj in objects:
                    rows.append((obj.name, "失败: %s" % exc))
    finally:
        restore_selection(context, previous_selection, previous_active)
    return rows


# ---------------------------------------------------------------------------
# 设置与结果列
# ---------------------------------------------------------------------------

class UVMB_ReportItem(PropertyGroup):
    obj_name: StringProperty(name="物体")
    applied: IntProperty(name="已关联面数")
    total: IntProperty(name="总面数")
    note: StringProperty(name="说明")


def store_report(scene, rows):
    items = scene.uvmb_report
    while len(items):
        items.remove(0)
    for name, applied, total, note in rows:
        item = items.add()
        item.obj_name = name
        item.applied = int(applied)
        item.total = int(total)
        item.note = note or ""


class UVMB_Settings(PropertyGroup):
    # ---- UV 展开 ----
    method: EnumProperty(
        name="展开方式",
        description="使用 Blender 自带的哪种自动展开方式",
        items=[
            ('SMART', "智能UV投影", "Smart UV Project: 自动切岛并打包"),
            ('UNWRAP', "展开(角度/共形)", "Unwrap: 按接缝正常展开"),
            ('LIGHTMAP', "光照图打包", "Lightmap Pack: 每个面单独摆一个方块"),
            ('CUBE', "立方体投影", "Cube Projection: 按立方体方向投影"),
        ],
        default='SMART',
    )
    angle_limit: FloatProperty(
        name="角度限制", description="智能投影中判断面属于同一岛的角度阈值",
        subtype='ANGLE', default=math.radians(66.0),
        min=math.radians(1.0), max=math.radians(89.0),
    )
    island_margin: FloatProperty(
        name="岛间距", description="UV 岛之间的间隔",
        default=0.001, min=0.0, max=1.0, precision=4,
    )
    area_weight: FloatProperty(
        name="面积权重", description="按面积调整 UV 密度的权重(0 = 不按面积)",
        default=0.0, min=0.0, max=1.0,
    )
    margin: FloatProperty(
        name="边距", description="展开/打包时使用的边距",
        default=0.001, min=0.0, max=1.0, precision=4,
    )
    cube_size: FloatProperty(
        name="投影大小", description="立方体投影使用的尺寸",
        default=1.0, min=0.0001, max=1000.0,
    )
    margin_method: EnumProperty(
        name="间距方式",
        items=[
            ('SCALED', "按比例缩放", ""),
            ('ADD', "直接相加", ""),
            ('FRACTION', "按比例(%)", ""),
        ],
        default='SCALED',
    )
    rotate_method: EnumProperty(
        name="旋转方式",
        description="UV 岛旋转对齐方式; 当前版本不支持的值会自动换成最接近的",
        items=[
            ('AXIS_ALIGNED', "轴向对齐(自动)", "旋转到最小矩形, 各版本都有"),
            ('AXIS_ALIGNED_Y', "轴向对齐(垂直)", "仅 Blender 5.x 支持"),
            ('AXIS_ALIGNED_X', "轴向对齐(水平)", "仅 Blender 5.x 支持"),
            ('CARDINAL', "90°对齐", "仅 Blender 4.x 及更早支持"),
        ],
        default='AXIS_ALIGNED',
    )
    unwrap_method: EnumProperty(
        name="展开算法",
        items=[
            ('ANGLE_BASED', "角度法", ""),
            ('CONFORMAL', "共形", ""),
            ('MINIMUM_STRETCH', "最小拉伸", ""),
        ],
        default='ANGLE_BASED',
    )
    correct_aspect: BoolProperty(
        name="修正纵横比", description="按图片/物体比例修正 UV",
        default=True,
    )
    scale_to_bounds: BoolProperty(
        name="适配边界", description="把 UV 缩放到 0-1 范围内",
        default=False,
    )
    pack_after: BoolProperty(
        name="平均岛缩放并重新打包", description="展开后统一 UV 密度再打包",
        default=True,
    )
    lightmap_margin: FloatProperty(
        name="光照图边距", description="光照图打包时每个方块周围的留空比例",
        default=0.1, min=0.001, max=1.0, precision=3,
    )
    per_object: BoolProperty(
        name="逐个物体处理",
        description="开启时每个物体单独进编辑模式展开, 相同形状的物体会得到完全一样的 UV 展开图, "
                    "这也是按 UV 关联材质的前提; 关闭时所有物体一起展开, 速度更快, "
                    "但它们会共用一张 UV 布局, 各物体的 UV 并不相同, 之后无法按 UV 关联材质",
        default=True,
    )

    # ---- 材质关联 ----
    match_mode: EnumProperty(
        name="匹配依据",
        description="如何在源物体上为每个面找到对应的面",
        items=[
            ('UV', "UV展开图一致", "按 UV 展开图中的位置匹配(推荐)"),
            ('FACE', "面序号一致", "要求两个物体拓扑完全一致"),
            ('POSITION', "3D位置一致", "按世界坐标位置匹配, 适合同一形状的副本"),
        ],
        default='UV',
    )
    uv_tolerance: FloatProperty(
        name="UV容差", description="UV 空间中认定两个面重合的距离阈值",
        default=0.001, min=0.000001, max=1.0, precision=6, step=0.01,
    )
    position_tolerance: FloatProperty(
        name="位置容差", description="3D 位置匹配时的距离阈值(场景单位)",
        default=0.001, min=0.000001, max=100.0, precision=5, step=0.01,
    )
    unmatched: EnumProperty(
        name="未匹配的面",
        description="目标物体上没有找到对应源面时的处理方式",
        items=[
            ('KEEP', "保留原有材质", "不动这些面的材质"),
            ('NEAREST', "取最近的源面", "忽略容差取最近的面, 可能不准"),
            ('FIRST', "用源物体第一个材质", "统一填充成源物体第一个材质"),
        ],
        default='KEEP',
    )
    copy_uv: BoolProperty(
        name="同时复制源物体的UV布局",
        description="要求两个物体循环数一致; 复制后 UV 完全一致, 材质分布自然逐面一一对应",
        default=False,
    )
    make_single_user: BoolProperty(
        name="多用户网格自动转单用户",
        description="目标网格被多个物体共用时先复制一份, 避免误改其它物体",
        default=True,
    )

    # ---- 镜像处理 ----
    handle_mirror: BoolProperty(
        name="检测镜像(修改器/已应用的镜像)",
        description="自动判断物体有没有镜像修改器, 以及网格是不是已经被镜像过(几何对称检测), "
                    "已应用的镜像修改器同样能查出来",
        default=True,
    )
    mirror_uv_fix: BoolProperty(
        name="镜像物体自动对齐UV",
        description="当目标物体与源物体成镜像关系时, 自动把目标的 UV 镜像/对齐成与源一致, "
                    "这样源物体上不同位置的材质分布就能正确关联过去",
        default=True,
    )
    mirror_axis: EnumProperty(
        name="镜像轴",
        description="自动检测或手动指定镜像轴",
        items=[
            ('AUTO', "自动检测", ""),
            ('X', "X轴", ""),
            ('Y', "Y轴", ""),
            ('Z', "Z轴", ""),
        ],
        default='AUTO',
    )
    mirror_uv_axis: EnumProperty(
        name="UV镜像方向",
        description="自动挑选匹配率最高的方案, 也可以手动限定镜像方向",
        items=[
            ('AUTO', "自动", ""),
            ('U', "水平U (U -> 1-U)", ""),
            ('V', "垂直V (V -> 1-V)", ""),
            ('UV', "U和V都镜像", ""),
        ],
        default='AUTO',
    )
    mirror_tolerance: FloatProperty(
        name="镜像检测容差",
        description="相对物体尺寸的容差比例, 越大越容易判定为镜像",
        default=0.0005, min=0.000001, max=0.05, precision=6,
    )


# ---------------------------------------------------------------------------
# 算子
# ---------------------------------------------------------------------------

def low_match_hint(stats):
    """匹配率过低时给出的排查提示。"""
    faces = stats.get("faces", 0)
    if not faces:
        return None
    ratio = float(stats.get("matched", 0)) / float(faces)
    if ratio >= 0.5:
        return None
    return (
        "提示: 只有 %.0f%% 的面在源物体上找到对应的面。请确认两个物体的 UV 展开图一致"
        "(建议勾选「逐个物体处理」再展开, 取消勾选时所有物体共用一张 UV 布局, 各物体 UV 并不相同);"
        "也可以适当调大 UV 容差, 或改用「3D位置一致」匹配。" % (ratio * 100.0)
    )


class UVMB_OT_unwrap(Operator):
    bl_idname = "uvmb.unwrap_selected"
    bl_label = "批量展开 (选中物体)"
    bl_description = "对物体模式下选中的全部网格物体执行 Blender 自带的自动 UV 展开"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and bool(mesh_objects(context))

    def execute(self, context):
        settings = get_settings(context)
        rows = unwrap_all_objects(context, mesh_objects(context), settings)
        report_rows = [(name, 0, 0, status) for name, status in rows]
        report_rows += skipped_report_rows(context)
        store_report(context.scene, report_rows)
        failed = [name for name, status in rows if status.startswith("失败")]
        message = "已展开 %d 个物体" % (len(rows) - len(failed))
        if failed:
            message += ", 失败 %d 个: %s" % (len(failed), ", ".join(failed[:5]))
        summary = skipped_summary(context)
        if summary:
            message += "; " + summary
        self.report({'WARNING'} if failed else {'INFO'}, message)
        return {'FINISHED'}


class UVMB_OT_link_materials(Operator):
    bl_idname = "uvmb.link_materials"
    bl_label = "关联材质 (活动物体 -> 选中物体)"
    bl_description = "以活动物体为源, 按 UV 展开图把分区域的材质分布关联到其它选中物体(材质数据块共享)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.mode != 'OBJECT':
            return False
        active = context.active_object
        if active is None or active.type != 'MESH' or active.data is None:
            return False
        return bool(mesh_objects(context, skip=active))

    def execute(self, context):
        settings = get_settings(context)
        source = context.active_object
        targets = mesh_objects(context, skip=source)
        rows, error, stats = link_materials(context, source, targets, settings)
        if error:
            store_report(context.scene, [])
            self.report({'ERROR'}, error)
            return {'CANCELLED'}

        store_report(context.scene, list(rows) + skipped_report_rows(context, skip=source))
        context.view_layer.update()
        total_faces = sum(row[2] for row in rows)
        total_applied = sum(row[1] for row in rows)
        message = "已从 [%s] 关联材质到 %d 个物体, 共写入 %d/%d 个面" % (
            source.name, len(targets), total_applied, total_faces
        )
        summary = skipped_summary(context, skip=source)
        if summary:
            message += "; " + summary
        hint = low_match_hint(stats)
        if hint:
            self.report({'WARNING'}, message + " | " + hint)
        else:
            self.report({'INFO'}, message)
        return {'FINISHED'}


class UVMB_OT_unwrap_and_link(Operator):
    bl_idname = "uvmb.unwrap_and_link"
    bl_label = "展开并关联材质 (一键)"
    bl_description = "先把选中物体全部展开, 再以活动物体为源关联材质分布"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.mode != 'OBJECT':
            return False
        active = context.active_object
        if active is None or active.type != 'MESH' or active.data is None:
            return False
        return bool(mesh_objects(context, skip=active))

    def execute(self, context):
        settings = get_settings(context)
        source = context.active_object
        targets = mesh_objects(context, skip=source)

        unwrap_rows = unwrap_all_objects(context, mesh_objects(context), settings)
        failed = [name for name, status in unwrap_rows if status.startswith("失败")]
        if failed:
            self.report({'WARNING'}, "展开失败: %s" % ", ".join(failed[:5]))

        rows, error, stats = link_materials(context, source, targets, settings)
        if error:
            store_report(context.scene, [])
            self.report({'ERROR'}, error)
            return {'CANCELLED'}

        store_report(context.scene, list(rows) + skipped_report_rows(context, skip=source))
        context.view_layer.update()
        total_faces = sum(row[2] for row in rows)
        total_applied = sum(row[1] for row in rows)
        message = "已展开 %d 个物体, 并从 [%s] 关联材质到 %d 个物体 (%d/%d 个面)" % (
            len(unwrap_rows) - len(failed), source.name, len(targets), total_applied, total_faces
        )
        summary = skipped_summary(context, skip=source)
        if summary:
            message += "; " + summary
        hint = low_match_hint(stats)
        if hint:
            self.report({'WARNING'}, message + " | " + hint)
        else:
            self.report({'INFO'}, message)
        return {'FINISHED'}


class UVMB_OT_check_match(Operator):
    bl_idname = "uvmb.check_match"
    bl_label = "检查与活动物体的UV匹配度"
    bl_description = "按当前匹配设置检查每个选中物体有多少面能在活动物体上找到对应面"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if context.mode != 'OBJECT':
            return False
        active = context.active_object
        if active is None or active.type != 'MESH' or active.data is None:
            return False
        return bool(mesh_objects(context, skip=active))

    def execute(self, context):
        settings = get_settings(context)
        source = context.active_object
        targets = mesh_objects(context, skip=source)
        source_mesh = source.data
        mode = settings.match_mode

        source_uv = active_uv_layer(source_mesh)
        if mode == MATCH_UV and source_uv is None:
            store_report(context.scene, [])
            self.report({'ERROR'}, "源物体 [%s] 没有 UV 图层" % source.name)
            return {'CANCELLED'}

        index = build_source_index(
            source, mode, settings.uv_tolerance, settings.position_tolerance, source_uv
        )
        rows = []
        worst = 1.0
        for target in targets:
            mesh = target.data
            target_uv = active_uv_layer(mesh)
            total = len(mesh.polygons)
            if mode == MATCH_UV and target_uv is None:
                rows.append((target.name, 0, total, "没有 UV 图层"))
                worst = 0.0
                continue
            _mapping, matched = compute_face_map(
                source, target, mesh, mode, settings, index, target_uv
            )
            if total:
                worst = min(worst, float(matched) / float(total))
            note = "UV 一致" if matched == total and total else "有 %d 个面未匹配" % (total - matched)
            relation = mirror_relation(source, target, settings) if mode == MATCH_UV else None
            if relation is not None:
                note += " | 与源成镜像关系(%s轴, %.0f%%), 关联时会自动对齐UV" % (
                    relation["axis"], relation["ratio"] * 100.0
                )
            rows.append((target.name, matched, total, note))

        store_report(context.scene, rows)
        self.report({'INFO'}, "已检查 %d 个物体, 最低匹配率 %.1f%%" % (len(rows), worst * 100.0))
        return {'FINISHED'}


class UVMB_OT_detect_mirror(Operator):
    bl_idname = "uvmb.detect_mirror"
    bl_label = "检测镜像"
    bl_description = "检查选中物体的镜像情况: 镜像修改器(含UV镜像设置)以及网格是否已经被镜像过(几何对称检测)"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and bool(mesh_objects(context))

    def execute(self, context):
        settings = get_settings(context)
        rows = []
        mirrored = 0
        objects = mesh_objects(context)
        for obj in objects:
            info = object_mirror_info(obj, settings)
            if info["has_mirror"]:
                mirrored += 1
            rows.append((obj.name, 0, 0, info["text"]))
        rows += skipped_report_rows(context)
        store_report(context.scene, rows)
        self.report(
            {'INFO'},
            "已检测 %d 个网格物体, 其中 %d 个有镜像特征" % (len(objects), mirrored),
        )
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# 面板
# ---------------------------------------------------------------------------

class UVMB_PT_panel(Panel):
    bl_idname = "UVMB_PT_panel"
    bl_label = "批量UV展开 / 材质关联"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'UV工具'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = get_settings(context)
        meshes = mesh_objects(context)
        active = context.active_object

        box = layout.box()
        column = box.column(align=True)
        column.label(text="选中网格物体: %d 个" % len(meshes), icon='MESH_DATA')
        if active is not None and active.type == 'MESH':
            column.label(text="源物体: %s" % active.name, icon='OBJECT_DATA')
        else:
            column.label(text="源物体: 请在物体模式下选中一个网格", icon='ERROR')

        box = layout.box()
        box.label(text="1. 自动UV展开", icon='UV')
        column = box.column(align=True)
        column.prop(settings, "method", text="")
        if settings.method == 'SMART':
            column.prop(settings, "angle_limit")
            column.prop(settings, "island_margin")
            column.prop(settings, "area_weight")
            column.prop(settings, "margin_method")
            column.prop(settings, "rotate_method")
        elif settings.method == 'UNWRAP':
            column.prop(settings, "unwrap_method")
            column.prop(settings, "margin")
            column.prop(settings, "pack_after")
        elif settings.method == 'LIGHTMAP':
            column.prop(settings, "lightmap_margin")
        else:
            column.prop(settings, "cube_size")
        row = column.row(align=True)
        row.prop(settings, "correct_aspect")
        row.prop(settings, "scale_to_bounds")
        column.prop(settings, "per_object")
        column.operator(UVMB_OT_unwrap.bl_idname, icon='PLAY', text="批量展开选中物体")

        box = layout.box()
        box.label(text="2. 关联材质分布", icon='MATERIAL')
        column = box.column(align=True)
        column.prop(settings, "match_mode", text="")
        if settings.match_mode == MATCH_UV:
            column.prop(settings, "uv_tolerance")
        elif settings.match_mode == MATCH_POSITION:
            column.prop(settings, "position_tolerance")
        column.prop(settings, "unmatched")
        column.prop(settings, "copy_uv")
        column.prop(settings, "make_single_user")

        mirror_box = box.box()
        mirror_box.label(text="镜像处理", icon='MOD_MIRROR')
        mirror_column = mirror_box.column(align=True)
        mirror_column.prop(settings, "handle_mirror")
        sub = mirror_column.column(align=True)
        sub.enabled = settings.handle_mirror
        sub.prop(settings, "mirror_uv_fix")
        sub.prop(settings, "mirror_axis")
        uv_sub = sub.column(align=True)
        uv_sub.enabled = settings.mirror_uv_fix
        uv_sub.prop(settings, "mirror_uv_axis")
        sub.prop(settings, "mirror_tolerance")
        mirror_column.operator(UVMB_OT_detect_mirror.bl_idname, icon='ZOOM_SELECTED', text="检测镜像")

        column.operator(UVMB_OT_link_materials.bl_idname, icon='LINKED', text="关联材质到选中物体")
        column.operator(UVMB_OT_check_match.bl_idname, icon='ZOOM_SELECTED', text="检查UV匹配度")

        column = layout.column(align=True)
        column.scale_y = 1.3
        column.operator(UVMB_OT_unwrap_and_link.bl_idname, icon='AUTO', text="展开 + 关联材质 (一键)")

        items = scene.uvmb_report
        if len(items):
            box = layout.box()
            box.label(text="结果 (%d)" % len(items), icon='INFO')
            column = box.column(align=True)
            for item in items:
                if item.total > 0:
                    ratio = float(item.applied) / float(item.total)
                    icon = 'CHECKMARK' if ratio >= 0.999 else ('ERROR' if ratio < 0.5 else 'INFO')
                    column.label(
                        text="%s: %d/%d (%.0f%%)" % (item.obj_name, item.applied, item.total, ratio * 100.0),
                        icon=icon,
                    )
                    if item.note:
                        column.label(text="    " + item.note, icon='INFO')
                else:
                    column.label(text="%s: %s" % (item.obj_name, item.note or "-"), icon='INFO')


def menu_func_unwrap(self, context):
    self.layout.operator(UVMB_OT_unwrap.bl_idname, icon='UV')
    self.layout.operator(UVMB_OT_link_materials.bl_idname, icon='MATERIAL')


# ---------------------------------------------------------------------------
# 注册
# ---------------------------------------------------------------------------

CLASSES = (
    UVMB_ReportItem,
    UVMB_Settings,
    UVMB_OT_unwrap,
    UVMB_OT_link_materials,
    UVMB_OT_unwrap_and_link,
    UVMB_OT_check_match,
    UVMB_OT_detect_mirror,
    UVMB_PT_panel,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.uvmb_settings = PointerProperty(type=UVMB_Settings)
    bpy.types.Scene.uvmb_report = CollectionProperty(type=UVMB_ReportItem)
    if hasattr(bpy.types, "VIEW3D_MT_object"):
        bpy.types.VIEW3D_MT_object.append(menu_func_unwrap)


def unregister():
    if hasattr(bpy.types, "VIEW3D_MT_object"):
        bpy.types.VIEW3D_MT_object.remove(menu_func_unwrap)
    if hasattr(bpy.types.Scene, "uvmb_report"):
        del bpy.types.Scene.uvmb_report
    if hasattr(bpy.types.Scene, "uvmb_settings"):
        del bpy.types.Scene.uvmb_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
